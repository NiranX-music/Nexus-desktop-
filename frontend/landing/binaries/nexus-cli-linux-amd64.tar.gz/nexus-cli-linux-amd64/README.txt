NEXUS OS — Linux AMD64 Binary Bundle
==================================================
Version: 4.2.0-enterprise
Target: Ubuntu / Debian / Arch / Fedora / RHEL

Quickstart:
  1. Extract archive:
     tar -xzf nexus-cli-linux-amd64.tar.gz
     cd nexus-cli-linux-amd64

  2. Run node health check:
     ./nexus status

  3. Start background daemon:
     ./nexus start

  4. Run continuous self-healing watchdog:
     ./nexus inspector --daemon

Team Notifications:
  Critical alerts route directly to:
  - barhateniranjan725@gmail.com (Owner)
  - niranjanbarhate42@gmail.com (Tech Lead)
  - niranjanbarhate36@gmail.com (SecOps)
